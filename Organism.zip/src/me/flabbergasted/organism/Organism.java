/*
  you can put a one sentence description of your library here.
  
  (c) copyright
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
 */

package me.flabbergasted.organism;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import processing.core.PApplet;

/**
 * Organism is the main class that glues an sketch to server logs.
 * 
 * @example Organism 
 * @author Mathias Dahlstr�m
 * 
 */
public class Organism implements Runnable {

	public static Integer ACTIVITIES_SITES = 0;
	public static Integer ACTIVITIES_URLS = 1;
	public static Integer ACTIVITIES_SLOW_REQUESTS = 2;
	public static Integer ACTIVITIES_CONTENT = 3;
	public static Integer ACTIVITIES_USERS = 4;
	public static Integer ACTIVITIES_REFERAL = 5;
	public static Integer ACTIVITIES_USERAGENT = 6;
	public static Integer ACTIVITIES_HTTP_RETURN_CODE = 7;
	
	public static Integer EVENTS_INFO = 8;
	public static Integer EVENTS_WARNINGS = 9;
	
	public static Integer ATTRIBUTES_TYPE = 10;
	public static Integer ATTRIBUTES_NAME = 11;
	public static Integer ATTRIBUTES_HOST = 12;
	public static Integer ATTRIBUTES_REQUEST_COMPLETITION_TIME = 13;
	public static Integer ATTRIBUTES_MESSAGE = 14;
	
	
	private PApplet myParent;
	private Method eventCallback;
	private Method activityCallback;
	private HashMap<String,ServerConfig> serverMappings;
	private Thread serverPingLoop;
	private HashMap<ServerConfig,HashMap<Integer, Vector<Rules>>> actvitiesRules = new HashMap<ServerConfig,HashMap<Integer, Vector<Rules>>>();
	private HashMap<ServerConfig,HashMap<Integer, Vector<Rules>>> eventsRules = new HashMap<ServerConfig,HashMap<Integer, Vector<Rules>>>();
	public final String VERSION = "0.4.0";

	/**
	 * a Constructor, usually called in the setup() method in your sketch to
	 * initialize and start the library.
	 * 
	 * @example Hello
	 * @param theParent
	 */
	public Organism(PApplet theParent) {
		myParent = theParent;
		serverMappings = new HashMap<String,ServerConfig>();
		serverPingLoop = new Thread(this);
		serverPingLoop.start();
		try {
			eventCallback = myParent.getClass().getMethod("organismEvent", new Class[] { Event.class });
			activityCallback = myParent.getClass().getMethod("organismActivity", new Class[] { Activity.class });
		} catch (Exception e) {
			System.out.println("No Organism callback found");
		    System.out.println(e);
		}

	}

	
	@Override
	protected void finalize() throws Throwable {
		serverPingLoop = null;
		super.finalize();
	}


	/**
	 * return the version of the library.
	 * 
	 * @return String
	 */
	public String version() {
		return VERSION;
	}
	
	/**
	 *  add a server configuration as an organism and connect to the server.
	 *  After this call, server information will be reported back to through the callbak methods
	 *  
	 */
	public void addServer(ServerConfig config) {
		serverMappings.put(config.servername, config);
		HashMap<Integer, Vector<Rules>> emptyActivityRuleCollection = new HashMap<Integer, Vector<Rules>>();
		HashMap<Integer, Vector<Rules>> emptyEventRuleCollection = new HashMap<Integer, Vector<Rules>>();
		actvitiesRules.put(config,emptyActivityRuleCollection);
		eventsRules.put(config, emptyEventRuleCollection);
		config.setOrganism(this);
		config.connect();
	}


	@Override
	public void run() {
		Thread thisThread = Thread.currentThread();
        while (serverPingLoop == thisThread) {
            Collection<ServerConfig> servers = serverMappings.values();
            Iterator<ServerConfig> iterations = servers.iterator();
            while(iterations.hasNext()){
            	ServerConfig server = iterations.next();
            	server.pingServer();
            }
        	try {
                Thread.sleep(200);
            } catch (InterruptedException e){
            }
        }
		
	}
	
	public void new_activity(Activity activity) {
		Vector<Rules> rules = actvitiesRules.get(serverMappings.get(activity.serverName)).get(activity.type);
		if(rules != null) {	
			Iterator<Rules> i = rules.iterator();
			while(i.hasNext()){
				Rules rule = i.next();
				if( !rule.validateRule(activity.data) ) {
					return;
				}
			}
		}		
		try {
			activityCallback.invoke(myParent, new Object[] { activity });
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void new_event(Event event) {
		Vector<Rules> rules = eventsRules.get(serverMappings.get(event.serverName)).get(event.type);
		if(rules != null) {	
			Iterator<Rules> i = rules.iterator();
			while(i.hasNext()){
				Rules rule = i.next();
				if( !rule.validateRule(event.data) ) {
					return;
				}	
			}
		}
		try {
			eventCallback.invoke(myParent, new Object[] { event });
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addEventRule(ServerConfig config, Integer event, Rules rules) {
		HashMap<Integer,Vector<Rules>> ruleSets = eventsRules.get(config);
		if(ruleSets == null) {
			ruleSets = new HashMap<Integer,Vector<Rules>>();
			eventsRules.put(config, ruleSets);
		}
		Vector<Rules> ruleSet = ruleSets.get(event);
		if(ruleSet == null) {
			ruleSet = new Vector<Rules>();
			ruleSets.put(event,ruleSet);
		}
		ruleSet.add(rules);
	}
	
	public void addActivityRule(ServerConfig config, Integer event, Rules rules) {
		HashMap<Integer,Vector<Rules>> ruleSets =  actvitiesRules.get(config);
		if(ruleSets == null) {
			ruleSets = new HashMap<Integer,Vector<Rules>>();
			actvitiesRules.put(config, ruleSets);
		}
		Vector<Rules> ruleSet = ruleSets.get(event);
		if(ruleSet == null) {
			ruleSet = new Vector<Rules>();
			ruleSets.put(event,ruleSet);
		}
		ruleSet.add(rules);
	}

}
