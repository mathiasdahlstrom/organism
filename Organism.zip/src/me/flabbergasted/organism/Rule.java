package me.flabbergasted.organism;

public class Rule implements Rules {
	
	public static final int EQUAL = 0;
	public static final int LESS = 1;
	public static final int MORE = 2;
	public static final int CONTAINS = 3;
	public static final int NOT = 4;
	public static final int CONTAINS_NO = 5;
	
	protected int comparision;
	protected String data;
	
	
	public Rule(int ruleType, String comparsionData) {
		comparision = ruleType;
		data = comparsionData;
	}
	
	/* (non-Javadoc)
	 * @see me.flabbergasted.organism.Rule#validateRule(java.lang.String)
	 */
	public boolean validateRule(String stringToValidate) {
		boolean result = false;
		if(stringToValidate == null)
			return result;
		switch (comparision) {
		case EQUAL:
			if(data.compareTo(stringToValidate) == 0)
				result = true;
			break;
		case LESS:
			if(data.compareTo(stringToValidate) < 0)
				result = true;
			break;
		case MORE:
			if(data.compareTo(stringToValidate) > 0)
				result = true;
			break;
		case CONTAINS:
			if(stringToValidate.contains(data))
				result = true;
			break;
		case NOT:
			if(data.indexOf(stringToValidate) < 0)
				result = true;
			break;
		case CONTAINS_NO:
			if(!stringToValidate.contains(data))
				result = true;
		}
		return result;
	}
}
