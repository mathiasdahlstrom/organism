package me.flabbergasted.organism;

public interface Rules {

	public abstract boolean validateRule(String stringToValidate);

}