package me.flabbergasted.organism;

public class Activity {
	public Integer type;
	public Integer name;
	public String data;
	public float executionTime;
	public String serverName;
}
