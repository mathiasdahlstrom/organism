package me.flabbergasted.organism;

import me.flabbergasted.organism.connectors.*;
import me.flabbergasted.organism.parsers.*;

public class ServerConfig {
	public static final int RAILS = 0;
	public static final int APACHE = 1;
	public static final int NGINX = 2;
	public static final int LOCAL = 3;
	public static final int SSH = 4;

	public int type;
	public int connection;
	
	public String logfile;
	public String username;
	public String password;
	public String hostname;
	public String servername;
	
	private Parser parser;
	private Connector server;
	
	private Organism organism;
	
	
	public ServerConfig(String serverName) {
		servername = serverName;
	}
	
	public void setOrganism(Organism organism) {
		this.organism = organism;
	}

	public Organism getOrganism() {
		return organism;
	}
	
	protected void connect() {
		createServerConnection();
		createServerParser();
	}
	
	protected void pingServer() {
		if(server != null)
			server.do_process();
	}

	private void createServerConnection(){
		if(connection == SSH){
			server = new SSHConnector(hostname, username, password, logfile);
		}
		else if(connection == LOCAL){
			server = new FileConnector(logfile);
		}
		server.setServerName(servername);
		server.setOrganism(organism);
	}
	
	private void createServerParser() {
		if(type == RAILS){
			parser = new Rails(servername, organism);
		}
		else if(type == NGINX){
			parser = new Nginx(servername, organism);
		}
		server.setServerParser(parser);
	}
	
}
