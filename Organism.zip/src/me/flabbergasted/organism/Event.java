package me.flabbergasted.organism;

public class Event {
	public Integer type;
	public String name;
	public String data;
	public String serverName;
}
