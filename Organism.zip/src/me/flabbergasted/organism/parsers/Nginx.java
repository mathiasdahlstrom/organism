/**
 * 
 */
package me.flabbergasted.organism.parsers;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import me.flabbergasted.organism.Organism;
import me.flabbergasted.organism.Activity;

/**
 * @author Mathias Dahlstr�m
 *
 */
public class Nginx extends Parser {

	Pattern request_pattern = Pattern.compile("^([^\\s]+) - ([^\\s]+) (\\[[^\"]*\\]) (\"[^\"]*\") (\\d+) (\\d+) (\"[^\"]*\") (\"[^\"]*\")");
	String sample = "87.194.220.4 - - [17/May/2009:10:32:51 +0000] \"GET /favicon.ico HTTP/1.1\" 404 169 \"-\" \"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; en-US; rv:1.9.0.10) Gecko/2009042315 Firefox/3.0.10\"";
	
	/**
	 * @param serverCollection
	 * @param host
	 * @param user
	 * @param pwd
	 * @param logFile
	 */
	public Nginx(String name, Organism owner) {
		super(name, owner);
	}

	/* (non-Javadoc)
	 * @see me.flabbergasted.organism.parsers.Parser#process_line(java.lang.String)
	 */
	@Override
	public void process_line(String logStatment) {
		Matcher request_match = request_pattern.matcher(logStatment);
		String remote_ip = null, remote_user = null, timestamp = null, http_status = null, request_size = null, http_user_agent = null, http_referal = null;
		String[] resource = null;
		if(request_match.matches()) {
			remote_ip = request_match.group(1);
			remote_user = request_match.group(2);
			timestamp = request_match.group(3);
			resource = request_match.group(4).split(" ");
			http_status = request_match.group(5);
			request_size = request_match.group(6);
			http_referal = request_match.group(7);
			http_user_agent = request_match.group(8);
		}
		if(resource != null)
			this.add_activity_urls(resource, request_size);
	    
		this.add_activity_users(remote_ip);
	    
	    if(http_referal != null)
	    	this.add_activity_referal(http_referal);
	    
	    if(http_user_agent != null)
	    	this.add_activity_useragent(http_user_agent);
	    
	    this.add_activity_status(http_status);
	    
	    if(resource != null)
	    	this.add_activity_content(resource);
	}

	private void add_activity_urls(String[] resource, String resource_completion_time) {
		if(resource.length < 3)
			return;
		Activity activity = new Activity();
		activity.type = Organism.ACTIVITIES_URLS;
		activity.name = Organism.ATTRIBUTES_NAME;
		activity.data = resource[1];
		activity.executionTime = Float.valueOf(resource_completion_time)/1000;
		activity.serverName = serverName;
		organism.new_activity(activity);
	}
	
	private void add_activity_users(String user) {
		Activity activity = new Activity();
		activity.type = Organism.ACTIVITIES_USERS; // Activities.USERS;
		activity.name = Organism.ATTRIBUTES_HOST; //Attributes.HOST;
		activity.data = user;
		activity.serverName = serverName;
		organism.new_activity(activity);
	}
	
	private void add_activity_referal(String http_referal) {
		Activity activity = new Activity();
		activity.type = Organism.ACTIVITIES_REFERAL; //Activities.REFERAL;
		activity.name = Organism.ATTRIBUTES_HOST; //Attributes.HOST;
		activity.data = http_referal;
		activity.serverName = serverName;
		organism.new_activity(activity);
	}
	
	private void add_activity_useragent(String user_agent) {
		Activity activity = new Activity();
		activity.type = Organism.ACTIVITIES_USERAGENT; //Activities.USERAGENT;
		activity.name = Organism.ATTRIBUTES_NAME; //Attributes.NAME;
		activity.data = user_agent;
		activity.serverName = serverName;
		organism.new_activity(activity);
	}
	
	private void add_activity_status(String http_status) {
		Activity activity = new Activity();
		activity.type = Organism.ACTIVITIES_HTTP_RETURN_CODE; //Activities.HTTP_RETURN_CODE;
		activity.name = Organism.ATTRIBUTES_NAME; //Attributes.NAME;
		activity.data = http_status;
		activity.serverName = serverName;
		organism.new_activity(activity);
	}
	
	private void add_activity_content(String[] resource) {
		if(resource.length < 2)
			return;
		String url = resource[1];
		String type;
		if( url.contains(".gif") || url.contains(".jpg") || url.contains(".png") || url.contains(".ico") )
	        type = "image";
		else if ( url.contains(".css") )
	        type = "css";
	    else if ( url.contains(".js") )
	        type = "javascript";
	    else if ( url.contains(".swf") )
	        type = "flash";
	    else if( url.contains(".avi") || url.contains(".ogm") || url.contains(".flv") || url.contains(".mpg") )
	        type = "movie";
	    else if( url.contains(".mp3") || url.contains(".wav") || url.contains(".fla") || url.contains(".aac") || url.contains(".ogg") )
	        type = "music";
	    else
	        type = "page";
		
		Activity activity = new Activity();
		activity.type = Organism.ACTIVITIES_CONTENT; //Activities.CONTENT;
		activity.name = Organism.ATTRIBUTES_NAME; //Attributes.NAME;
		activity.data = type;
		activity.serverName = serverName;
		organism.new_activity(activity);
	}
}
