package me.flabbergasted.organism.parsers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import me.flabbergasted.organism.Organism;
import me.flabbergasted.organism.Activity;
import me.flabbergasted.organism.Event;

public class Rails extends Parser {
	Pattern old_rails_style = Pattern.compile("/^Completed in ([\\d.]+) .* \\[([^\\]]+)\\]/");
	Pattern new_rails_style = Pattern.compile("^Completed in ([\\d]+)ms .* \\[([^\\]]+)\\]");
	Pattern error_pattern = Pattern.compile("^([^ ]+Error) \\((.*)\\):");
	Pattern processing_pattern = Pattern.compile("^Processing .* \\(for (\\d+.\\d+.\\d+.\\d+) at .*\\).*$");
	Pattern http_pattern = Pattern.compile("^http[s]?:\\/\\/([^\\/]*)(.*)");

	public Rails(String name, Organism owner) {
		super(name,owner);
	}

	@Override
	public void process_line(String logStatement) {
		if(check_For_url(logStatement)) ;
		else if(check_for_user(logStatement)) ;
		else if(check_for_error(logStatement)) ;
	}

	public boolean check_For_url(String line) {
		String url = null;
		String ms_time = null;
		Matcher old_rails_match = old_rails_style.matcher(line);
		Matcher new_rails_match = new_rails_style.matcher(line);
		if( old_rails_match.matches() ) {
			ms_time = old_rails_match.group(1);
			url = old_rails_match.group(2);
		}
		else if( new_rails_match.matches() ) {
			ms_time = new_rails_match.group(1);
			url = new_rails_match.group(2);
		}
		
		if (url == "http:// /") {
			url = null;
		}
		
		if(url != null && ms_time != null) {
			Matcher http_match = http_pattern.matcher(url);
			if(http_match.matches()) {
				Activity activity;
				//SITES
				activity = new Activity();
				activity.type = Organism.ACTIVITIES_SITES; //Activities.SITES;
				activity.name = Organism.ATTRIBUTES_NAME; //Attributes.NAME;
				activity.data = http_match.group(1);
				activity.executionTime = Float.valueOf(ms_time)/1000;
				activity.serverName = serverName;
				organism.new_activity(activity);
				
				//URLS
				activity = new Activity();
				activity.type = Organism.ACTIVITIES_URLS; //Activities.URLS;
				activity.name = Organism.ATTRIBUTES_NAME; //Attributes.NAME;
				activity.data = http_match.group(2);
				activity.executionTime = Float.valueOf(ms_time)/1000;
				activity.serverName = serverName;
				organism.new_activity(activity);
				
				//slow requests
				activity = new Activity();
				activity.type = Organism.ACTIVITIES_SLOW_REQUESTS; //Activities.SLOW_REQUESTS;
				activity.name = Organism.ATTRIBUTES_NAME; //Attributes.NAME;
				activity.data = http_match.group(2);
				activity.executionTime = Float.valueOf(ms_time)/1000;
				activity.serverName = serverName;
				organism.new_activity(activity);
				
				//Content
				activity = new Activity();
				activity.type = Organism.ACTIVITIES_CONTENT; //Activities.CONTENT;
				activity.name = Organism.ATTRIBUTES_NAME; //Attributes.NAME;
				activity.data = http_match.group(2);
				activity.executionTime = -1;
				activity.serverName = serverName;
				organism.new_activity(activity);
			}
			return true;
		}
		else
			return false;
	}
	
	public boolean check_for_user(String line) {
		String user_ip = null;
		if(line.contains("Processing ")) {
			Matcher processing_match = processing_pattern.matcher(line);
			if(processing_match.matches()) {
				user_ip = processing_match.group(1);
				Activity activity = new Activity();
				activity.type = Organism.ACTIVITIES_USERS;//Activities.USERS;
				activity.name = Organism.ATTRIBUTES_HOST; //Attributes.HOST;
				activity.serverName = serverName;
				organism.new_activity(activity);
			}
		}
		if(user_ip != null)
			return true;
		else
			return false;
	}
	
	public boolean check_for_error(String line) {
		String error = null;
		if(line.contains("Error (")) {
			Matcher error_match = error_pattern.matcher(line);
			if(error_match.matches()) {
				Event event = new Event();
				event.type = Organism.EVENTS_WARNINGS; //Events.WARNINGS;
				event.name = error_match.group(1);
				event.data = error_match.group(2);
				event.serverName = serverName;
				organism.new_event(event);
				error = "yes";
			}
		}
		if(error != null)
			return true;
		else
			return false;
	}
}
