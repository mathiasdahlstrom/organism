package me.flabbergasted.organism.parsers;

import me.flabbergasted.organism.Organism;

public abstract class Parser {
	;
	Organism organism;
	String serverName;
	
	public Parser(String name, Organism owner ) {
		serverName = name;
		organism = owner;
	}
	
	public abstract void process_line(String log_statment);
		
}
