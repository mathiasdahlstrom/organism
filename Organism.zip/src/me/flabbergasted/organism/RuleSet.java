package me.flabbergasted.organism;

import java.util.Iterator;
import java.util.Vector;

public class RuleSet implements Rules {

	Vector<Rules> rules = new Vector<Rules>();
	
	public void addRule(Rules rule) {
		rules.add(rule);
	}
	@Override
	public boolean validateRule(String stringToValidate) {
		boolean result = true;
		Iterator<Rules> i = rules.iterator();
		while(i.hasNext()) {
			Rules rule = i.next();
			if(!rule.validateRule(stringToValidate)) {
				result = false;
				break;
			}
		}
		return result;
	}

}
