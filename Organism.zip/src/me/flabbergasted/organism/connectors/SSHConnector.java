package me.flabbergasted.organism.connectors;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


import me.flabbergasted.organism.Organism;

import com.jcraft.jsch.*;

public class SSHConnector extends Connector{
	JSch jsch;
	Session session;
	Channel channel;
	StringBuffer logBuffer;
	InputStream logInputStream;
	InputStreamReader logReader;
	
	public SSHConnector(String host, String user, String pwd,String logFile) {
		String command = "tail -lf " + logFile;
		logBuffer = new StringBuffer();
		jsch = new JSch();
		try {
			jsch.setKnownHosts("~/.ssh/known_hosts");
			session = jsch.getSession(user, host);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(pwd);
			session.connect();
			channel=session.openChannel("exec");
			((ChannelExec)channel).setCommand(command);
			channel.setInputStream(null);
			((ChannelExec)channel).setErrStream(System.err);
			channel.setOutputStream(null);
			logInputStream = channel.getInputStream();
			logReader = new InputStreamReader(logInputStream); 
			channel.connect();
		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public SSHConnector(Organism serverCollection, String host, String user, String pwd, String proxy, String logFile) throws Exception {
		throw new Exception("SSH Connections through ssh proxy not implmented yet");
	}
	
	@Override
	protected void finalize() throws Throwable {
		channel.disconnect();
		session.disconnect();
		super.finalize();
	}

	public void do_process() {
		this.ping_ssh();
	}	
	
	private void ping_ssh() {
		try {
		while(logReader.ready() ) {
			char character = (char)logInputStream.read();
			if(character == 10) {
				String line = logBuffer.toString();
				interpreter.process_line(line);
				logBuffer = new StringBuffer();
			}
			else
				logBuffer.append(character);
		}
		if(channel.isClosed()) {
			System.out.println("Channel is closed exit-status: "+channel.getExitStatus());
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
