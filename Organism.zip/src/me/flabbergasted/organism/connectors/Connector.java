package me.flabbergasted.organism.connectors;

import me.flabbergasted.organism.Organism;
import me.flabbergasted.organism.parsers.Parser;

public abstract class Connector {
	
	Organism organism;
	String serverName;
	Parser interpreter;
	
	public void setServerName(String name) {
		serverName = name;
	}
	
	public void setServerParser(Parser serverParser) {
		interpreter = serverParser;
	}
	
	public void setOrganism(Organism owner) {
		organism = owner;
	}
	
	public abstract void do_process();

}
