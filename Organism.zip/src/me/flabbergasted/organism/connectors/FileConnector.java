package me.flabbergasted.organism.connectors;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileConnector extends Connector{
	BufferedReader buffer;
	FileReader fileReader;
	File logFile;
	
	public FileConnector(String logfilePath){
		logFile = new File(logfilePath);
		try {
			fileReader = new FileReader(logFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		buffer = new BufferedReader(fileReader);
		
	}
	
	@Override
	public void do_process() {
		String line = null;
		try {
			line = buffer.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(line != null && interpreter != null)
			interpreter.process_line(line);
	}

}
